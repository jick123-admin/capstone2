import sys

sys.path.append("../pip-package/flask")

from flask import Blueprint, render_template, request, redirect, url_for, flash
from config import get_db_connection

home_bp = Blueprint("home", __name__)

@home_bp.route("/")
def home():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users")
    users = cursor.fetchall()
    conn.close()
    return render_template("home.html", users=users)

@home_bp.route("/add", methods=["POST"])
def add_user():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO users (name, email) VALUES (%s, %s)", (name, email))
        conn.commit()
        conn.close()
        flash("User added successfully!", "success")
        return redirect(url_for("home.home"))

@home_bp.route("/edit/<int:id>", methods=["POST"])
def edit_user(id):
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET name=%s, email=%s WHERE id=%s", (name, email, id))
        conn.commit()
        conn.close()
        flash("User updated successfully!", "info")
        return redirect(url_for("home.home"))

@home_bp.route("/delete/<int:id>")
def delete_user(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM users WHERE id=%s", (id,))
    conn.commit()
    conn.close()
    flash("User deleted successfully!", "danger")
    return redirect(url_for("home.home"))
