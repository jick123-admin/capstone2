import sys

sys.path.append("../pip-package/flask")
import os
from flask import Flask
from home import home_bp

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Register blueprint
app.register_blueprint(home_bp, url_prefix="/")

if __name__ == "__main__":
    app.run(debug=True)
