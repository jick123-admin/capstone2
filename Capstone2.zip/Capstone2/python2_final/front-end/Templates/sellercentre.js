


 src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"


 src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"



        const products = [
            { title: "Item 1", description: "Description for item 1.", img: "https://via.placeholder.com/300x200" },
            { title: "Item 2", description: "Description for item 2.", img: "https://via.placeholder.com/300x200" },
            { title: "Item 3", description: "Description for item 3.", img: "https://via.placeholder.com/300x200" },
            { title: "Item 4", description: "Description for item 4.", img: "https://via.placeholder.com/300x200" },
            { title: "Item 5", description: "Description for item 5.", img: "https://via.placeholder.com/300x200" },
            { title: "Item 6", description: "Description for item 6.", img: "https://via.placeholder.com/300x200" },
            { title: "Item 7", description: "Description for item 7.", img: "https://via.placeholder.com/300x200" },
            { title: "Item 8", description: "Description for item 8.", img: "https://via.placeholder.com/300x200" },
            { title: "Item 9", description: "Description for item 9.", img: "https://via.placeholder.com/300x200" },
            { title: "Item 10", description: "Description for item 10.", img: "https://via.placeholder.com/300x200" }
        ];
    
        function loadProducts() {
            const productList = document.getElementById("product-list");
            products.forEach((product, index) => {
                const card = `
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="card">
                            <img src="${product.img}" alt="${product.title}">
                            <hr class="separator">
                            <div class="card-body">
                                <h5 class="card-title">${product.title}</h5>
                                <p class="card-text">${product.description.substring(0, 50)}...</p>
                                <button class="btn btn-primary" onclick="showDetails(${index})">See More...</button>
                            </div>
                        </div>
                    </div>
                `;
                productList.innerHTML += card;
            });
        }
    
        function showDetails(index) {
            document.getElementById("modalTitle").innerText = products[index].title;
            document.getElementById("modalDescription").innerText = products[index].description;
            new bootstrap.Modal(document.getElementById("infoModal")).show();
        }
    
        document.addEventListener("DOMContentLoaded", loadProducts);

    
src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"


 
   document.addEventListener("DOMContentLoaded", function() {
    // Bootstrap modals
    var viewProfileModal = new bootstrap.Modal(document.getElementById("viewProfileModal"));
    var editProfileModal = new bootstrap.Modal(document.getElementById("editProfileModal"));
    var logoutModal = new bootstrap.Modal(document.getElementById("logoutModal"));

    // Profile info (mock data)
    let profileData = {
        username: "John Doe",
        email: "johndoe@example.com",
        profilePic: "img/default-profile.png"
    };

    // View Profile
    document.getElementById("viewProfileBtn").addEventListener("click", function() {
        document.getElementById("profileUsername").innerText = profileData.username;
        document.getElementById("profileEmail").innerText = profileData.email;
        document.getElementById("profilePic").src = profileData.profilePic;
        viewProfileModal.show();
    });

    // Open Edit Profile Modal
    document.getElementById("editProfileBtn").addEventListener("click", function() {
        document.getElementById("editUsername").value = profileData.username;
        document.getElementById("editEmail").value = profileData.email;
        editProfileModal.show();
    });

    // Handle the profile photo upload
    document.getElementById("selectPhotoBtn").addEventListener("click", function() {
        document.getElementById("editProfilePic").click();  // Trigger the file input
    });

    document.getElementById("editProfilePic").addEventListener("change", function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = function() {
                // Set the new profile image and update the profile data
                profileData.profilePic = reader.result;
                document.getElementById("profilePic").src = reader.result; // Update the profile picture in the View Profile modal
                document.querySelector(".profile-btn img").src = reader.result; // Update the profile button image
            };
            reader.readAsDataURL(file);  // Read the file as a Data URL
        }
    });

    // Save Changes in Edit Profile
    document.getElementById("editProfileForm").addEventListener("submit", function(event) {
        event.preventDefault();
        profileData.username = document.getElementById("editUsername").value;
        profileData.email = document.getElementById("editEmail").value;
        alert("Profile updated successfully!");
        editProfileModal.hide();
    });

    // Logout Confirmation
    document.getElementById("logoutBtn").addEventListener("click", function() {
        logoutModal.show();
    });

    document.getElementById("confirmLogout").addEventListener("click", function() {
        alert("Logging out...");
        window.location.href = "login.html"; // Redirect to login page
    });
});
