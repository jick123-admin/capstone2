document.querySelectorAll(".open-modal").forEach(button => {
    button.addEventListener("click", function() {
        this.parentElement.nextElementSibling.style.display = "flex";
    });
});

document.querySelectorAll(".close").forEach(closeBtn => {
    closeBtn.addEventListener("click", function() {
        this.closest(".modal-container").style.display = "none";
    });
});
