# from flask import Blueprint, render_template, flash, session, redirect
import sys

sys.path.append("../../../pip-package/flask")
sys.path.append("../../../pip-pachage/pymysql")

from flask import Blueprint, request, redirect, url_for, flash, render_template, session
import os
import pymysql
# from config import DB_CONFIG
from config import get_db_connection

admin_bp = Blueprint("admin",__name__)

UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@admin_bp.route('/admin')
def admin_home():
    if "fullname" not in session or "label" not in session or "profile_id" not in session:
        flash("Please Login first","error")
        return redirect("/")
    # conn = pymysql.connect(**DB_CONFIG)
    conn = get_db_connection()
    # cursor = conn.cursor()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT id, filename, file_path FROM images where profile_id = %s",session["profile_id"])
    images = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template("admin/admin.html",fullname=session["fullname"],label=session["label"],images=images)

@admin_bp.route('/admin_delete/<int:image_id>', methods=['GET'])
def delete_image(image_id):
    # conn = pymysql.connect(**DB_CONFIG)
    conn = get_db_connection()
    # cursor = conn.cursor()
    cursor =  conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT file_path FROM images WHERE id = %s", (image_id))
    image = cursor.fetchone()
    if image:
        try:
            os.remove(image['file_path'])
        except FileNotFoundError:
            pass
    cursor.execute("DELETE FROM images WHERE id = %s", (image_id,))
    conn.commit()
    cursor.close()
    conn.close()
    flash('Image deleted successfully')
    return redirect("/admin")

@admin_bp.route('/admin_update/<int:image_id>', methods=['POST'])
def update_image_file(image_id):
    if 'file' in request.files:
        file = request.files['file']
        # conn = pymysql.connect(**DB_CONFIG)
        conn = get_db_connection()
        # cursor = conn.cursor()
        cursor = conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute("SELECT file_path FROM images WHERE id = %s", (image_id))
        image = cursor.fetchone()
        if image:
            try:
                os.remove(image['file_path'])
            except FileNotFoundError:
                pass
            filepath = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(filepath)
            cursor.execute("UPDATE images SET filename = %s, file_path = %s WHERE id = %s", (file.filename, filepath, image_id))
            conn.commit()
        cursor.close()
        conn.close()
        flash('Image updated successfully')
    return redirect("/admin")

@admin_bp.route('/admin_upload', methods=['POST'])
def upload():
    profile_id = session["profile_id"]
    if 'file' not in request.files:
        flash('No file part')
        # return redirect(url_for('index'))
        return redirect("/admin")
    file = request.files['file']
    if file.filename == '':
        flash('No selected file')
        # return redirect(url_for('index'))
        return redirect("/admin")
    if file:
        filepath = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(filepath)
        
        # conn = pymysql.connect(**DB_CONFIG)
        conn = get_db_connection()
        # cursor = conn.cursor()
        cursor = conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute("INSERT INTO images (profile_id, filename, file_path) VALUES (%s, %s, %s)", (profile_id, file.filename, filepath))
        conn.commit()
        cursor.close()
        conn.close()
        flash('File uploaded successfully')
        return redirect("/admin")
        
@admin_bp.route("/admin_logout")
def logout():
    session.clear()
    flash("You`ve been logout","Info")
    return redirect("/")


