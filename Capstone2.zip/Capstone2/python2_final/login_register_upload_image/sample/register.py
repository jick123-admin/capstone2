import sys

sys.path.append("../../pip-package/flask")
sys.path.append("../../pip-package/pymysql")

from flask import Blueprint,render_template,request,redirect,url_for,flash,session
from config import get_db_connection
import pymysql

sys.path.append("sample/buyer")
sys.path.append("sample/seller")
sys.path.append("sample/admin")

from buyer import buyer_bp
from seller import seller_bp
from admin import admin_bp
import random

register_bp = Blueprint('register',__name__)
register_bp.register_blueprint(buyer_bp)
register_bp.register_blueprint(seller_bp)
register_bp.register_blueprint(admin_bp)

@register_bp.route("/", methods=["GET", "POST"])
def login(): 
    if request.method == "POST":
        uname = request.form.get("username")
        upass = request.form.get("password")

        conn = get_db_connection()
        cursor = conn.cursor(pymysql.cursors.DictCursor)  # Use DictCursor here
        query = "SELECT * FROM users_account WHERE email = %s and password = %s"
        cursor.execute(query, (uname,upass))
        user = cursor.fetchone()
        conn.close()

        if user and user["password"] == upass and user["email"] == uname:  # Replace with hashed password check
            session["fullname"] = user["fullname"]
            session["label"] = user["label"]
            session["profile_id"] = user["profile_id"]
            if user and user["label"] == "buyer":
                return redirect("/buyer")
            elif user and user["label"] == "seller":
                return redirect("/seller")
            else:
                return redirect("/admin")
        else:
            flash("Invalid username or password", "error")

    return render_template("login.html")

    
@register_bp.route('/register',methods=["GET","POST"])
def register():
    fullname = ""
    email = ""
    password = ""
    profile_id = ""
    label = ""
    profile_picture = ""
    shop_name = ""
    status = ""
    
    if request.method == "POST":
        fullname=request.form.get("fullname")
        email=request.form.get("email")
        password=request.form.get("password")
        profile_id=''.join(chr(random.randint(32, 126)) for _ in range(100))
        label=request.form.get("mycheckbox")
        profile_picture=""

        if label:
            shop_name=request.form.get("shop_name")
            status="Not Approve as Seller"
            if email != "" and password != "":
                conn = get_db_connection()
                cursor = conn.cursor()  # Use a prepared statement
                query = "INSERT INTO users_account (fullname,email,password,profile_id,label,profile_picture,shop_name,status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
            
                try:
                    cursor.execute(query, (fullname,email,password,profile_id,label,profile_picture,shop_name,status))
                    conn.commit()
                    flash("Register Successfully wait for the approval to start your business", "success")  # Success alert
                    fullname = ""
                    email = ""
                    password = ""
                    profile_id = ""
                    label = ""
                    profile_picture = ""
                    shop_name = ""
                    status = ""
                except Exception as e:
                    conn.rollback()
                    flash(f"Error: {str(e)}", "danger")  # Error alert
                finally:
                    cursor.close()
                    conn.close()
                return redirect(url_for("register.register"))
            else:
                flash("you must fill up the all")
        else:
            label="buyer"
            shop_name=""
            status=""
            if email != "" and password != "":
                conn = get_db_connection()
                cursor = conn.cursor()  # Use a prepared statement
                query = "INSERT INTO users_account (fullname,email,password,profile_id,label,profile_picture,shop_name,status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
            
                try:
                    cursor.execute(query, (fullname,email,password,profile_id,label,profile_picture,shop_name,status))
                    conn.commit()
                    flash("Register Successfully", "success")  # Success alert
                    fullname = ""
                    email = ""
                    password = ""
                    profile_id = ""
                    label = ""
                    profile_picture = ""
                    shop_name = ""
                    status = ""
                except Exception as e:
                    conn.rollback()
                    flash(f"Error: {str(e)}", "danger")  # Error alert
                finally:
                    cursor.close()
                    conn.close()
                return redirect(url_for("register.register"))
            else:
                flash("you must fill up the all")
            
            
    return render_template("register.html")  # Change to your actual route

