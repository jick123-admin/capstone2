import sys

sys.path.append("../pip-package/flask")

from flask import Flask,session
import sys
sys.path.append('sample')
from register import register_bp
import os

server = Flask(__name__)
server.secret_key = os.urandom(24)
server.register_blueprint(register_bp)

if __name__ == "__main__":
    server.run(debug=True)
